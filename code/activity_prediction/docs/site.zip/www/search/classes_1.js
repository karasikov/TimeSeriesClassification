var searchData=
[
  ['bool',['bool',['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1bool.html',1,'com::karasikov::activityprediction::R']]],
  ['bool',['bool',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1bool.html',1,'android::support::v7::appcompat::R']]],
  ['buildconfig',['BuildConfig',['../classcom_1_1karasikov_1_1activityprediction_1_1_build_config.html',1,'com::karasikov::activityprediction']]],
  ['buildconfig',['BuildConfig',['../classcom_1_1karasikov_1_1activityprediction_1_1test_1_1_build_config.html',1,'com::karasikov::activityprediction::test']]]
];
