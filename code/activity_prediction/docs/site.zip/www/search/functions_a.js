var searchData=
[
  ['progress_5fmessage',['progress_message',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#a5817c43fcba2d3ebceb6ab97e382bf80',1,'com::karasikov::activityprediction::MainActivity']]]
];
