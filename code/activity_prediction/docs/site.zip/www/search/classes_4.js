var searchData=
[
  ['id',['id',['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1id.html',1,'com::karasikov::activityprediction::R']]],
  ['id',['id',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1id.html',1,'android::support::v7::appcompat::R']]],
  ['integer',['integer',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1integer.html',1,'android::support::v7::appcompat::R']]],
  ['integer',['integer',['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1integer.html',1,'com::karasikov::activityprediction::R']]]
];
