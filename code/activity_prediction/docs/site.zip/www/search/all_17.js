var searchData=
[
  ['y',['y',['../classcom_1_1karasikov_1_1activityprediction_1_1_acceleration.html#a03b9945311ced31c2e07d7167ed93a94',1,'com.karasikov.activityprediction.Acceleration.y()'],['../classserver_1_1_dataset.html#aae9186721296c50bcb86d16ef854fe32',1,'server.Dataset.y()']]]
];
