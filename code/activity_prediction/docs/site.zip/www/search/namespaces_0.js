var searchData=
[
  ['android',['android',['../namespaceandroid.html',1,'']]],
  ['appcompat',['appcompat',['../namespaceandroid_1_1support_1_1v7_1_1appcompat.html',1,'android::support::v7']]],
  ['support',['support',['../namespaceandroid_1_1support.html',1,'android']]],
  ['v7',['v7',['../namespaceandroid_1_1support_1_1v7.html',1,'android::support']]]
];
