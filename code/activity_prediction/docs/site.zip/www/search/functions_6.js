var searchData=
[
  ['handle',['handle',['../classserver_1_1_classifier.html#ad425f9b1ac802dfc682abcfdac6df077',1,'server::Classifier']]]
];
