var searchData=
[
  ['server',['Server',['../classserver_1_1_server.html',1,'server']]],
  ['string',['string',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1string.html',1,'android::support::v7::appcompat::R']]],
  ['string',['string',['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1string.html',1,'com::karasikov::activityprediction::R']]],
  ['style',['style',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1style.html',1,'android::support::v7::appcompat::R']]],
  ['style',['style',['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1style.html',1,'com::karasikov::activityprediction::R']]],
  ['styleable',['styleable',['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1styleable.html',1,'com::karasikov::activityprediction::R']]],
  ['styleable',['styleable',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1styleable.html',1,'android::support::v7::appcompat::R']]]
];
