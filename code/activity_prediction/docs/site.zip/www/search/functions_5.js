var searchData=
[
  ['get_5ffeatures',['get_features',['../namespacesigproc.html#a948da950cf16bc8c5c7aa2606fdc27ed',1,'sigproc']]],
  ['getaccelerationfromsensor',['getAccelerationFromSensor',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#a8294a3380d9bb3dfc6b8f90a8d429bae',1,'com::karasikov::activityprediction::MainActivity']]],
  ['gettimestamp',['getTimestamp',['../classcom_1_1karasikov_1_1activityprediction_1_1_acceleration.html#aacc95a6294d27c87446355b8526acdeb',1,'com::karasikov::activityprediction::Acceleration']]],
  ['getx',['getX',['../classcom_1_1karasikov_1_1activityprediction_1_1_acceleration.html#ac6048b1d41b604b2cd078243eb935169',1,'com::karasikov::activityprediction::Acceleration']]],
  ['gety',['getY',['../classcom_1_1karasikov_1_1activityprediction_1_1_acceleration.html#a66971311ae2fee5ec6fa1ace963e0b03',1,'com::karasikov::activityprediction::Acceleration']]],
  ['getz',['getZ',['../classcom_1_1karasikov_1_1activityprediction_1_1_acceleration.html#ade8ee67f90dfbed5e6af10e1123bb4e4',1,'com::karasikov::activityprediction::Acceleration']]]
];
