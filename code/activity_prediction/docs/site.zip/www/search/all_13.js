var searchData=
[
  ['up',['up',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1id.html#aa1a26c91fc306fe374117d6f7a87a22f',1,'android.support.v7.appcompat.R.id.up()'],['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1id.html#a704c50d731dc8850b77dca113c82c8f0',1,'com.karasikov.activityprediction.R.id.up()']]],
  ['updatecounter',['updateCounter',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#abe0b98040e48153d410ddd55ab21468c',1,'com::karasikov::activityprediction::MainActivity']]],
  ['uselogo',['useLogo',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1id.html#aa40aa2ab6df98b640cbae616bbd9e658',1,'android.support.v7.appcompat.R.id.useLogo()'],['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1id.html#abb91e50e8bb160fb61fe58212c110460',1,'com.karasikov.activityprediction.R.id.useLogo()']]]
];
