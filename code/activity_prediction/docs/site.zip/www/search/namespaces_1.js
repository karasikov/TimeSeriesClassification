var searchData=
[
  ['activityprediction',['activityprediction',['../namespacecom_1_1karasikov_1_1activityprediction.html',1,'com::karasikov']]],
  ['com',['com',['../namespacecom.html',1,'']]],
  ['connection',['Connection',['../namespace_connection.html',1,'']]],
  ['karasikov',['karasikov',['../namespacecom_1_1karasikov.html',1,'com']]],
  ['test',['test',['../namespacecom_1_1karasikov_1_1activityprediction_1_1test.html',1,'com::karasikov::activityprediction']]]
];
