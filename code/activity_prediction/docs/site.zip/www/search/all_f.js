var searchData=
[
  ['querybackground',['queryBackground',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1attr.html#a8d51ae1010aee4e891d15815fbdcf879',1,'android.support.v7.appcompat.R.attr.queryBackground()'],['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1attr.html#adb2c13dcd40bd7df8d92d80131fa2b93',1,'com.karasikov.activityprediction.R.attr.queryBackground()']]],
  ['queryhint',['queryHint',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1attr.html#ab9b8ac4051819a9ad89287c48cf1d630',1,'android.support.v7.appcompat.R.attr.queryHint()'],['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1attr.html#a2dd6da92ca6ddc953cc14eb309014a1d',1,'com.karasikov.activityprediction.R.attr.queryHint()']]]
];
