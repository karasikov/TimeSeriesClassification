var searchData=
[
  ['binary_5fsearch',['binary_search',['../namespacesigproc.html#aca63feff99bff6f96f5f29b2f2dbc28d',1,'sigproc']]]
];
