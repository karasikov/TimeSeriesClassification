var searchData=
[
  ['send_5fstring',['send_string',['../class_connection_1_1_connection.html#a9b2c581ff8707336f2e4fd6453a29dfa',1,'Connection::Connection']]],
  ['sendstring',['SendString',['../classcom_1_1karasikov_1_1activityprediction_1_1_connection.html#a44aca53ac1c2de768fdeb34896bd783b',1,'com::karasikov::activityprediction::Connection']]],
  ['settimestamp',['setTimestamp',['../classcom_1_1karasikov_1_1activityprediction_1_1_acceleration.html#a82439a0c556be0c3e2e42b30a10323ac',1,'com::karasikov::activityprediction::Acceleration']]],
  ['setx',['setX',['../classcom_1_1karasikov_1_1activityprediction_1_1_acceleration.html#a17e8ea3a34405182b9d09a24017c4720',1,'com::karasikov::activityprediction::Acceleration']]],
  ['sety',['setY',['../classcom_1_1karasikov_1_1activityprediction_1_1_acceleration.html#a331f6d7dc680e713650d0c42aed6f161',1,'com::karasikov::activityprediction::Acceleration']]],
  ['setz',['setZ',['../classcom_1_1karasikov_1_1activityprediction_1_1_acceleration.html#a695ba6ab3165040ec30336cf906c1f97',1,'com::karasikov::activityprediction::Acceleration']]],
  ['startsensor',['startSensor',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#ac852a8a297a7a2a62af0c52cbb92b611',1,'com::karasikov::activityprediction::MainActivity']]],
  ['stopsensor',['stopSensor',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#aa5910af0a2c1932ee0bd65e0515baf8c',1,'com::karasikov::activityprediction::MainActivity']]]
];
