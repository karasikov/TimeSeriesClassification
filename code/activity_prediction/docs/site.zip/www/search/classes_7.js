var searchData=
[
  ['r',['R',['../classcom_1_1karasikov_1_1activityprediction_1_1_r.html',1,'com::karasikov::activityprediction']]],
  ['r',['R',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r.html',1,'android::support::v7::appcompat']]]
];
