var searchData=
[
  ['x',['x',['../classcom_1_1karasikov_1_1activityprediction_1_1_acceleration.html#a6dbbdfbe5b70bd7ab1fc440c9754188d',1,'com.karasikov.activityprediction.Acceleration.x()'],['../classserver_1_1_dataset.html#a3f5c1ecf94e41b93191020243533234f',1,'server.Dataset.X()']]]
];
