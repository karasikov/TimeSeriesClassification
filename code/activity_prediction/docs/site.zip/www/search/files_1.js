var searchData=
[
  ['buildconfig_2ejava',['BuildConfig.java',['../android_test_2debug_2com_2karasikov_2activityprediction_2test_2_build_config_8java.html',1,'']]],
  ['buildconfig_2ejava',['BuildConfig.java',['../release_2com_2karasikov_2activityprediction_2_build_config_8java.html',1,'']]],
  ['buildconfig_2ejava',['BuildConfig.java',['../debug_2com_2karasikov_2activityprediction_2_build_config_8java.html',1,'']]]
];
