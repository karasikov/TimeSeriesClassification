var searchData=
[
  ['r_2ejava',['R.java',['../debug_2android_2support_2v7_2appcompat_2_r_8java.html',1,'']]],
  ['r_2ejava',['R.java',['../release_2com_2karasikov_2activityprediction_2_r_8java.html',1,'']]],
  ['r_2ejava',['R.java',['../release_2android_2support_2v7_2appcompat_2_r_8java.html',1,'']]],
  ['r_2ejava',['R.java',['../debug_2com_2karasikov_2activityprediction_2_r_8java.html',1,'']]]
];
