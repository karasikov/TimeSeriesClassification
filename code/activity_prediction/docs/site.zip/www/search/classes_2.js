var searchData=
[
  ['classifier',['Classifier',['../classserver_1_1_classifier.html',1,'server']]],
  ['color',['color',['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1color.html',1,'com::karasikov::activityprediction::R']]],
  ['color',['color',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1color.html',1,'android::support::v7::appcompat::R']]],
  ['connection',['Connection',['../classcom_1_1karasikov_1_1activityprediction_1_1_connection.html',1,'com::karasikov::activityprediction']]],
  ['connection',['Connection',['../class_connection_1_1_connection.html',1,'Connection']]]
];
