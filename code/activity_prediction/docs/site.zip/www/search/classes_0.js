var searchData=
[
  ['acceleration',['Acceleration',['../classcom_1_1karasikov_1_1activityprediction_1_1_acceleration.html',1,'com::karasikov::activityprediction']]],
  ['anim',['anim',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1anim.html',1,'android::support::v7::appcompat::R']]],
  ['anim',['anim',['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1anim.html',1,'com::karasikov::activityprediction::R']]],
  ['applicationtest',['ApplicationTest',['../classcom_1_1karasikov_1_1activityprediction_1_1_application_test.html',1,'com::karasikov::activityprediction']]],
  ['attr',['attr',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1attr.html',1,'android::support::v7::appcompat::R']]],
  ['attr',['attr',['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1attr.html',1,'com::karasikov::activityprediction::R']]]
];
