var searchData=
[
  ['calculate_5far_5fcoefficients',['calculate_ar_coefficients',['../namespacesigproc.html#afea4a11c15da76b3c87ca8279c6e38ff',1,'sigproc']]],
  ['connection',['Connection',['../classcom_1_1karasikov_1_1activityprediction_1_1_connection.html#a0f39b83b780c03f4a3eb9570a9ff3b13',1,'com::karasikov::activityprediction::Connection']]]
];
