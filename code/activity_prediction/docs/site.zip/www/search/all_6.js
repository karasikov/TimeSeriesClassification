var searchData=
[
  ['flavor',['FLAVOR',['../classcom_1_1karasikov_1_1activityprediction_1_1test_1_1_build_config.html#abe94376270f4907e142436a903340509',1,'com.karasikov.activityprediction.test.BuildConfig.FLAVOR()'],['../classcom_1_1karasikov_1_1activityprediction_1_1_build_config.html#ae83499cba625c26030688bd1db9603fe',1,'com.karasikov.activityprediction.BuildConfig.FLAVOR()']]],
  ['frequency',['FREQUENCY',['../namespaceserver.html#a5081afa3046d5b0bfee77e04aa94c1aa',1,'server']]]
];
