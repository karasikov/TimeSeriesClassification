var searchData=
[
  ['onaccuracychanged',['onAccuracyChanged',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#afa061d5405c0d5297696ad7a9d20dedd',1,'com::karasikov::activityprediction::MainActivity']]],
  ['oncreate',['onCreate',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#a59b744c039af797911beb94f1aac594a',1,'com::karasikov::activityprediction::MainActivity']]],
  ['oncreateoptionsmenu',['onCreateOptionsMenu',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#adcc7390aa50b8c0fa00865b674e78056',1,'com::karasikov::activityprediction::MainActivity']]],
  ['onoptionsitemselected',['onOptionsItemSelected',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#a37d74a7ba166f17c3a003f3a182ce1f8',1,'com::karasikov::activityprediction::MainActivity']]],
  ['onpause',['onPause',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#a3783d35cbe8ba80ead0b2c746a80574d',1,'com::karasikov::activityprediction::MainActivity']]],
  ['onresume',['onResume',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#a27b2eea7a0008165fa042ac23c4a2503',1,'com::karasikov::activityprediction::MainActivity']]],
  ['onsensorchanged',['onSensorChanged',['../classcom_1_1karasikov_1_1activityprediction_1_1_main_activity.html#ac5d701a8669200e95b17fdd1b013ad0c',1,'com::karasikov::activityprediction::MainActivity']]],
  ['out',['out',['../classcom_1_1karasikov_1_1activityprediction_1_1_connection.html#a43c1f18b1033baeeb1589e89fed5ef6e',1,'com::karasikov::activityprediction::Connection']]],
  ['overlapanchor',['overlapAnchor',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1attr.html#a311395081823a3475d2e7dfaf1f8c303',1,'android.support.v7.appcompat.R.attr.overlapAnchor()'],['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1attr.html#a6eefa9f650c92619b78ed2d22e1709f4',1,'com.karasikov.activityprediction.R.attr.overlapAnchor()']]]
];
