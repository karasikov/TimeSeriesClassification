var searchData=
[
  ['dataset',['Dataset',['../classserver_1_1_dataset.html',1,'server']]],
  ['dimen',['dimen',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1dimen.html',1,'android::support::v7::appcompat::R']]],
  ['dimen',['dimen',['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1dimen.html',1,'com::karasikov::activityprediction::R']]],
  ['drawable',['drawable',['../classandroid_1_1support_1_1v7_1_1appcompat_1_1_r_1_1drawable.html',1,'android::support::v7::appcompat::R']]],
  ['drawable',['drawable',['../classcom_1_1karasikov_1_1activityprediction_1_1_r_1_1drawable.html',1,'com::karasikov::activityprediction::R']]]
];
