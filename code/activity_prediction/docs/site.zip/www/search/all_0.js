var searchData=
[
  ['_5f_5fdel_5f_5f',['__del__',['../classserver_1_1_classifier.html#a4f962458890ecd2b2fac439802d4ce68',1,'server::Classifier']]],
  ['_5f_5finit_5f_5f',['__init__',['../class_connection_1_1_connection.html#a8c67eba51af8766aad2db19ceb7752ac',1,'Connection.Connection.__init__()'],['../classserver_1_1_dataset.html#a7c083cc9d5289715258dbafc8ae60f87',1,'server.Dataset.__init__()'],['../classserver_1_1_classifier.html#a14e89f384019001094690fe71614fa76',1,'server.Classifier.__init__()'],['../classserver_1_1_server.html#abfa57160834bb2b20f65a577249e4b4e',1,'server.Server.__init__()'],['../classsigproc_1_1_too_short_signal_exception.html#ae8ad4bea2629775867c95f2b159a3d49',1,'sigproc.TooShortSignalException.__init__()']]],
  ['_5fload_5fclassifier',['_load_classifier',['../classserver_1_1_classifier.html#a96b67d2399f730445f63d1b8d1405588',1,'server::Classifier']]],
  ['_5fpredict',['_predict',['../classserver_1_1_classifier.html#a22f6477562e2a4ab7102702aead61f17',1,'server::Classifier']]],
  ['_5fprepare_5fts',['_prepare_ts',['../classserver_1_1_classifier.html#ab14dd8b82d39e211d5d95da625b9ddba',1,'server::Classifier']]],
  ['_5fretrain_5fclassifier',['_retrain_classifier',['../classserver_1_1_classifier.html#a6ff1e57f8f20407fc5daf81f35676aed',1,'server::Classifier']]],
  ['_5ftrain',['_train',['../classserver_1_1_classifier.html#a23439f98d6daa48b3cee30fce68f7f49',1,'server::Classifier']]],
  ['_5fts_5flogging',['_ts_logging',['../classserver_1_1_classifier.html#adf74477b6ae2d14feec4722511e4db35',1,'server::Classifier']]]
];
